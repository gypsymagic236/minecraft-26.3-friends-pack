Install this ZIP without extracting it in Minecraft Java 26.3's resourcepacks folder.
The red/yellow Mob Spawn Indicator and Clearer Water are removed.
For controls and server features, see the public repository's README.
