#if defined(VT_MOB_SPAWN__VARYING_LIGHTLEVEL_LOCATION)
layout(location = VT_MOB_SPAWN__VARYING_LIGHTLEVEL_LOCATION) out vec2 mobSpawn_lightLevel;
#else
out vec2 mobSpawn_lightLevel;
#endif

#if defined(VT_MOB_SPAWN__VARYING_FACECOORDS_LOCATION)
layout(location = VT_MOB_SPAWN__VARYING_FACECOORDS_LOCATION) out vec2 mobSpawn_faceCoords;
#else
out vec2 mobSpawn_faceCoords;
#endif

#if defined(VT_MOB_SPAWN__VARYING_STAIRS_LOCATION)
layout(location = VT_MOB_SPAWN__VARYING_STAIRS_LOCATION) out float mobSpawn_stairs;
#else
out float mobSpawn_stairs;
#endif

#if defined(VT_MOB_SPAWN__USE_VERTEX_INDEX)
#define VT_MOB_SPAWN__VID gl_VertexIndex
#else
#define VT_MOB_SPAWN__VID gl_VertexID
#endif

vec2 mobSpawn_generateFaceCoords() {
    if (VT_MOB_SPAWN__VID % 4 == 0) return vec2(1.0,0.0);
    else if (VT_MOB_SPAWN__VID % 4 == 1) return vec2(1.0,1.0);
    else if (VT_MOB_SPAWN__VID % 4 == 2) return vec2(0.0,1.0);
    else if (VT_MOB_SPAWN__VID % 4 == 3) return vec2(0.0,0.0);
}

void mobSpawn_main(vec3 positionAttribute, ivec2 lightCoords) {
    if (!(fract(positionAttribute.x) >= 0.7 || fract(positionAttribute.z) >= 0.7) && (fract(positionAttribute.x) > 0.01 || fract(positionAttribute.z) > 0.01)) {
        mobSpawn_stairs = 1.0;
    } else {
        mobSpawn_stairs = 0.0;
    }

    mobSpawn_lightLevel = vec2(lightCoords);

    const vec2[4] corners = vec2[4](
        vec2(0, 1),
        vec2(0, 0),
        vec2(1, 0),
        vec2(1, 1)
    );

    mobSpawn_faceCoords = corners[VT_MOB_SPAWN__VID % 4];
}
