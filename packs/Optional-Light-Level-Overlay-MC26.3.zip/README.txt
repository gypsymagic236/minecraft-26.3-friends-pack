Optional red/yellow mob-spawn X overlay for Minecraft Java 26.3.
Install this ZIP without extracting it. Leave it disabled by default.
Activate it above Friends-Survival-26.3.zip only when you want the X marks.
